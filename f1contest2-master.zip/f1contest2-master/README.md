link: https://ak1303.github.io/f1contest2/
